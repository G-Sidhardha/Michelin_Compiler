type operator = Add | Sub | Mul | Div | Mod
type rop = Eq | Neq | Lt | Ltq | Gt | Gtq 
type re = And | Or
type datatypes = IntType | BoolType | StringType | DoubleType
type identifier = string*string

type expr =
    Binop of expr * operator * expr
    | Brela of expr * re * expr
    | Integer of string*string
    | String of string*string
    | Bool of string*string
    | Boolean of expr * rop * expr 
    | Double of string*string
    | ID of identifier
    | Access of expr * string
    | Bracket of expr
    | Null 
    | Noexpr

type variable_decl = {
    vname : identifier;
    vtype : datatypes;
}

type variable_def = {
    vdname : identifier;
    vdtype : datatypes;
    vdasn : expr;
}

type variable = 
    Attr_decl of variable_decl
    |Attr_def of variable_def

type statement = 
    Locals of variable
    |Asn of identifier * expr
    |Block of statement list
    |Return of expr
    |If of expr * statement list* statement list 
    |For of expr * expr * expr * statement list
    |While of expr * statement list

type arg_decl = {
    argname : identifier;
    argtype : datatypes; 
}

type func = {
    ftype : datatypes;
    fname : identifier;
    arguments : arg_decl list;
    body : statement list;
}

type class_unit =
    Attr of variable 
    |Func of func

type class_decl = class_unit list

type class_noI_info = {
    cname : identifier;
    cbody : class_decl;
}

type class_I_info = {
    cname : identifier;
    cbody : class_decl;
    access : string*string;
    iname : identifier;
}


type class_info =
        Inherits of class_I_info
        |NoInherits of class_noI_info

type entry =
        Classes of class_info
        |Func of func

type program = entry list

type env = {
	mutable functions: entry list; (*Not Sure!!!!!!*)
}

(* Returns true when given name is same as that of variables's name else returns false *)
let function_var_name name = function
	variable -> variable.vname = name

(* Returns true when given name is same as that of function's name else returns false. *)
let function_equal_name name = function
	func -> func.fname = name

let class_equal_name name = function
    _class -> _class.cname = name


(* Returns true when given name is same as that of argument's name else returns false. *)
let function_farg_name name = function
	arg -> arg.argname = name 


(*Checks if function has been declared or not.*)
let exist_function_name name env = List.exists (function_equal_name name) env.functions

(* Checks whether a function has been defined more than once.*)
let function_exist func env = 
	let name = func.fname in
	   try
		   let _ = List.find (function_equal_name name) env.functions in             
			   let e = "Duplicate function: "^ name ^" has been defined more than once." in
				   raise (Failure e)
		with Not_found -> false


(* Checks if the function name is there in the list of functions.*)
let get_function_by_name name env = 
	try
		   let result = List.find (function_equal_name name) env.functions in
			      result
  with Not_found -> raise(Failure("Function "^ name ^ " has not been declared."))


(* Checks if the a variable 'name' has been declared.*)
let get_variable_by_name name func = 
	try
		let result = List.find(function_var_name name) func.locals in
		result
	with Not_found -> raise(Failure("Local variable " ^ name ^ "is not declared."))


(* Checks if the a parameter 'name' has been declared *)
let get_formal_by_name name func = 
	try
		let result = List.find(function_fparam_name name) func.arguments in
			result
	with Not_found -> raise(Failure("Parameter" ^ name ^ " is not declared."))
